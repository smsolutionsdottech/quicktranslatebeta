Many of the icons in this directory were created by Mark James and are licensed under the Creative Commons Attribution 2.5 License
Find more of the Silk 1.3 series at: http://famfamfam.com/lab/icons/silk/
http://creativecommons.org/licenses/by/2.5/